/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/styles.css"],
  theme: {
    extend: {},
  },
  plugins: [],
}

