const { Blog } = require('../models/Blog');
const sequelize = require('../app');

const blogPostsData = [

    {
        title: 'Sample blog post',
        content: 'This is a sample text block for techie thoughts blog!'
    },

    {
        title: 'A blog about JSON',
        content: 'JavaScript Object Notation is a large and fascinating topic'
        
    },

    {
        title: 'Another post about Sequelize? Yes!',
        content: 'Sequelize is a database object relational mapping tool'
    }

];

const seedBlog = async () => {
    try {
        const addBlog = await Blog.bulkCreate(blogPostsData);
        console.log('Blog posts seeded!')
    } catch (error) {
        console.error('Failed to seed', error);
    }
};

seedBlog();